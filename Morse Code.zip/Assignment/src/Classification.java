
/**
 * The kinds of roads: A road, B road etc
 * @author Chris Loftus
 * @version 1.0 (30th January 2015)
 *
 */
public enum Classification {
	M, A, B, U
}
