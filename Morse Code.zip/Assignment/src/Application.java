

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Main class to test the Road and Settlement classes
 * 
 * @author Chris Loftus (add your name and change version number/date)
 * @version 1.0 (24th February 2016)
 *
 */
public class Application {


	private Map map;
	public Scanner userInput = new Scanner(System.in);
	private ArrayList<Settlement> settlements = new ArrayList<Settlement>();
	private ArrayList<Settlement> saveSettlement = new ArrayList<Settlement>();
	private ArrayList<Road> roads = new ArrayList<Road>();
 
	public Application() {
	
		map = new Map();
	}
	

	private void runMenu() {
		// STEP 1: ADD MENU CODE HERE
		printMenu();
	

	
	
	
		
	}

	// STEP 1: ADD PRIVATE UTILITY MENTHODS HERE. askForRoadClassifier, save and load provided
	
	private Classification askForRoadClassifier() {
		Classification result = null;
		boolean valid;
		do{
			valid = false;
			System.out.print("Enter a road classification: ");
			for (Classification cls: Classification.values()){
				System.out.print(cls + " ");
			}
			String choice = userInput.nextLine().toUpperCase();
			try {
				result = Classification.valueOf(choice);
				valid = true;
			} catch (IllegalArgumentException iae){
				System.out.println(choice + " is not one of the options. Try again.");
			}
		}while(!valid);
		return result;
	}
	
	private void save() {
		map.save();
	}

	private void load() {
		map.load();
	}

	private void printMenu() {
		// STEP 1: ADD CODE HERE
		System.out.println("What would you like to do?");
		System.out.println("1-Create a Settlement");
		System.out.println("2-Delete a Settlement");
		System.out.println("3-Create a Road");
		System.out.println("4-Delete a Road");
		System.out.println("5-Display Map");
		System.out.println("6-Save");
		System.out.println("7-Quit");
		

		int choose = userInput.nextInt();
		userInput.nextLine();
		
		
		switch (choose){
		case 1: 
			addSettlement();
			
			break;
	//case 2 :
	//		addRoad();
	//		break;
			/*	
		case 3:
			addRoad();
			break;
		case 4:
			deleteRoad();
			break;
		case 5:
			Displaymap();
			break;
		case 6:
			Savemap();
			break;
		
			
		 */
	}
	}

	public static void main(String args[]) {
		Application app = new Application();
		
		app.runMenu();
		main(null);
		
		
	}
	
	 public void addSettlement()
	 {
		 System.out.println("Please type in the settlement name");
		 String name = userInput.nextLine();
		 System.out.println("Please type in the population size of the settlement");
		 int pop = userInput.nextInt();
		 userInput.nextLine();
		 System.out.println("Please type in the number of the settlement type you would like to assign");
		 System.out.println("1: Hamlet");
		 System.out.println("2: City");	 
		 System.out.println("3: Town");
		 System.out.println("4: Village");
		 int setting = userInput.nextInt();
		 userInput.nextLine();
		 SettlementType newSettleK = SettlementType.CITY;

		 switch (setting)

{
case 1:
	newSettleK = SettlementType.HAMLET;
	break;
	
case 2:
	newSettleK = SettlementType.CITY;
	break;
	
case 3:
	newSettleK = SettlementType.TOWN;
	break;
	
case 4:
	newSettleK = SettlementType.VILLAGE;
	break;
	
 
}
		 new Settlement(name, newSettleK,pop);	 
	 
	 }


	 public void add(Road road) throws IllegalArgumentException {
		 
	
		
		System.out.println("Please type in the road name ");
		 String name = userInput.nextLine();
		 Classification choice=askForRoadClassifier();
/*		 System.out.println("Please enter the source Settlement ");
		 Settlement sourceset = userInput.nextLine();
		 userInput.nextLine();
		 System.out.println("Please enter the destination Settlement");
		Settlement destinationset = userInput.nextLine();
		 userInput.nextLine();
	
		 double distance = userInput.nextInt();
		 userInput.nextLine();
	
		 
		roads=  new Road (name,choice,sourceset,destinationset,distance);
*/
	 }


		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
