/**
 * 
 * @author Chris Loftus 
 * @version 1.0 (25th February 2016)
 *
 */

public class Map {

	public Map() {
		// INSERT CODE
		

		
		
	}

	/**
	 * In this version we display the result of calling toString on the command
	 * line. Future versions may display graphically
	 */
	public void display() {
		System.out.println(toString());
	}

	public void addSettlement(Settlement newSettlement) throws IllegalArgumentException {
		// STEP 5: INSERT CODE HERE
		
		
	}

	// STEPS 7-10: INSERT METHODS HERE, i.e. those similar to addSettlement and required
	// by the Application class
	public void deleteSettlement(){
		
		
	
	}
	
	public void addRoad(Road newRoad) throws IllegalArgumentException{
		
		
		
	}
	
	
	
	
	public void load() {
		// STEP 6: INSERT CODE HERE

		
		
		
		
	}

	public void save() {
		// STEP 6: INSERT CODE HERE
	
	
		load();
		
	}

	public String toString() {
		String result = "";
		
		return result;
	}
}
